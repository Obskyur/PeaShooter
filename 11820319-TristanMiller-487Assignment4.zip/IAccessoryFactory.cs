﻿namespace PeaShooter
{
    internal interface IAccessoryFactory
    {
        Accessory? Create(int option);
    }
}
