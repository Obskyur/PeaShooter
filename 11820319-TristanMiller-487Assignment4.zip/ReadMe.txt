This project can be run as-is in Visual Studio 2019+.
Simply open the solution file and run the project.